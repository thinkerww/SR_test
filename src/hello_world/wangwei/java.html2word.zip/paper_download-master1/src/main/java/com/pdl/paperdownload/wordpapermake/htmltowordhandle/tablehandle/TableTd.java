package com.pdl.paperdownload.wordpapermake.htmltowordhandle.tablehandle;

public class TableTd {
	
   private String tdStr;
   
   private Integer width;
   
   private Integer rowsapn;
   
   private Integer colspan;

public String getTdStr() {
	return tdStr;
}

public void setTdStr(String tdStr) {
	this.tdStr = tdStr;
}

public Integer getWidth() {
	return width;
}

public void setWidth(Integer width) {
	this.width = width;
}

public Integer getRowsapn() {
	return rowsapn;
}

public void setRowsapn(Integer rowsapn) {
	this.rowsapn = rowsapn;
}

public Integer getColspan() {
	return colspan;
}

public void setColspan(Integer colspan) {
	this.colspan = colspan;
}
   
   
}
